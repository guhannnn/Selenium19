package com.example.selenium1.sample.sel;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	WebDriverManager.firefoxdriver().setup();
    	WebDriver driver=new FirefoxDriver();
    	String url="https://demo.opencart.com/index.php?route=account/register&language=en-gb";
    	driver.get(url);
    	 
        driver.manage().window().maximize();
        
        JavascriptExecutor js =  (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)", args);
        
        
        //By ID and Class
//        driver.findElement(By.id("input-firstname")).sendKeys("Geethan");
//        driver.findElement(By.id("input-lastname")).sendKeys("KR");
//        driver.findElement(By.id("input-email")).sendKeys("727721euai018@skcet.ac.in");
//        driver.findElement(By.id("input-password")).sendKeys("skcetai21018");
//        driver.findElement(By.id("input-newsletter-yes")).click();
//        Thread.sleep(5000);
//        driver.findElement(By.xpath("/html/body/main/div[2]/div/div/form/div/div/div/input")).click();
//        driver.findElement(By.xpath("/html/body/main/div[2]/div/div/form/div/div/button")).click();
        
        
        
        //By XPath
//        driver.findElement(By.xpath("//input[@name=\"firstname\"]")).sendKeys("Geethan");
//        driver.findElement(By.xpath("//input[@name=\"lastname\"]")).sendKeys("KR");
//        driver.findElement(By.xpath("//input[@name=\"email\"]")).sendKeys("727721euai018@skcet.ac.in");
//        driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("skcetai21018");
//        driver.findElement(By.xpath("//*[@id=\"form-register\"]/fieldset[3]/div/div/div[1]/label")).click();
//        driver.findElement(By.xpath("//*[@id=\"form-register\"]/div/div/div/input")).click();
//        driver.findElement(By.xpath("//*[@id=\"form-register\"]/div/div/button")).click();
        
        
        
        //Test4
//        driver.navigate().to("https://j2store.net/free/");
//
//        driver.manage().window().maximize();
//
//        driver.findElement(By.xpath("//*[@id=\"Mod112\"]/div/div/ul/li[1]/a/img")).click();
//
//        driver.navigate().back();
//
//        driver.navigate().forward();
//
//        Thread.sleep(5000);
//
//        driver.navigate().refresh();
        
        //Test5
        String curl= driver.getCurrentUrl();
        if(curl.equals(url)) {
        	System.out.println("Valid");
        }
        
    }
}
