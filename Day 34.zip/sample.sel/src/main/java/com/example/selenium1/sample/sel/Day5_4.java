package com.example.selenium1.sample.sel;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Day5_4 {
    public static void main( String[] args ) throws InterruptedException
    {
    	WebDriverManager.firefoxdriver().setup();
    	WebDriver driver=new FirefoxDriver();
    	String url="https://www.abhibus.com/bus-ticket-booking";
    	driver.get(url);
    	driver.findElement(By.xpath("//*[@id=\"source\"]")).sendKeys("Coimbatore",Keys.ENTER);
    	System.out.println("Source");
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("//*[@id=\"destination\"]")).sendKeys("Nagercoil",Keys.ENTER);
    	System.out.println("Destination");
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("//*[@id=\"seo_search_btn\"]")).click();
    	System.out.println("Click");
    	JavascriptExecutor js =  (JavascriptExecutor) driver;
    	WebElement datepicker=driver.findElement(By.xpath("//*[@id=\"datepicker1\"]"));
    	js.executeScript("arguements[0].setAttribute('value','27/04/2023')",datepicker);
//    	JavascriptExecutor js = (JavascriptExecutor) driver;
//  	  js.executeScript("arguments[0].setAttribute('value','27/04/2023')", datepicker);
    	}
}
//test ng is a unit testing framework
//methods are present in class, class is present in shoot, ie shoot is also known as package