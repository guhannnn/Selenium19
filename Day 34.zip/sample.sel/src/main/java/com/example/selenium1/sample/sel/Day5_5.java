package com.example.selenium1.sample.sel;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Day5_5 {
	public static void main( String[] args ) throws InterruptedException
    {
    	WebDriverManager.firefoxdriver().setup();
    	WebDriver driver=new FirefoxDriver();
    	WebDriver driverr=new FirefoxDriver();
    	WebDriver driverrr=new FirefoxDriver();
    	String url="https://www.google.com/";
    	driver.get(url);
    	driverr.get(url);
    	driverrr.get(url);
    	
    	driver.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("Apple",Keys.ENTER);
    	driverr.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("Selenium",Keys.ENTER);
    	driverrr.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("Cucumber",Keys.ENTER);
    	
    	String t1=driver.getTitle();
    	System.out.println(t1);
    	
    	String t2=driverr.getTitle();
    	System.out.println(t2);
    	
    	String t3=driverrr.getTitle();
    	System.out.println(t3);
    	
    	String msg1=driver.getWindowHandle();
    	System.out.println(msg1);
    	String msg2=driverr.getWindowHandle();
    	System.out.println(msg2);
    	String msg3=driverrr.getWindowHandle();
    	System.out.println(msg3);
    	
    }
}
