package day7.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class NewTest4 {
	// directory where output is to be printed
	ExtentSparkReporter spark = new ExtentSparkReporter("TestingReports.html");
	ExtentReports extent = new ExtentReports();
	static ExtentTest test;
	WebDriver driver;
	@BeforeMethod
	public void before() {
		extent.attachReporter(spark);
		spark.config().setDocumentTitle("MyReporthtml");
		spark.config().setReportName("MyReport");
		spark.config().setTheme(Theme.DARK);

		
		WebDriverManager.firefoxdriver().setup();
//	  WebDriverManager.firefoxdriver().setup();
		driver=new FirefoxDriver();
	}
  @Test
  public void t1() throws InterruptedException {
	  String url="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	  driver.get(url);
      driver.manage().window().maximize();
      Thread.sleep(5000);
      System.out.println("t1");
      driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys("Admin");
      Thread.sleep(2000);
      driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys("admin123");
      Thread.sleep(2000);
      driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
      Thread.sleep(5000);
      String gurl=driver.getCurrentUrl();
	  String aurl="https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
	  Assert.assertEquals(aurl, gurl);
	  System.out.println("t2");
	  test=extent.createTest("TestCase1","Checking  username and password is done");
  }
  @AfterMethod
  public void aftertest(ITestResult result) throws InterruptedException {
	  if(result.getStatus()==ITestResult.FAILURE) {
		  test.log(Status.FAIL, result.getName());
	  }
	  else if(result.getStatus()==ITestResult.SUCCESS) {
		  test.log(Status.PASS, result.getName());
	  }
	  else {
		  test.log(Status.SKIP, result.getName());
	  }
	  Thread.sleep(7000);
	  driver.quit();
	  System.out.println("t3");
	  System.out.println("t4");
	  
  }
  @AfterSuite
  public void aftersuuite() {
	  extent.flush();
  }
}
