package day7.selenium;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class calculatortng {
//add
  @Test(dataProvider = "addition")
  public void add(int n, int s,int res) {
	  int ans=n+s;
	  Assert.assertEquals(res, ans);
  }
  
  
  //sub
  @Test(dataProvider = "subtraction")
  public void sub(int n, int s,int res) {
	  int ans=n-s;
	  Assert.assertEquals(res, ans);
  }
  
  
  //mul
  @Test(dataProvider = "multiplication")
  public void mul(int n, int s,int res) {
	  int ans=n*s;
	  Assert.assertEquals(res, ans);
  }
  
  
  //div
  @Test(dataProvider = "division")
  public void div(int n, int s,int res) {
	  int ans=n/s;
	  Assert.assertEquals(res, ans);
  }
  
  
  @DataProvider
  public Object[][] addition() {
    return new Object[][] {
      new Object[] { 1, 2,3 }
    };
  }
  @DataProvider
  public Object[][] subtraction() {
    return new Object[][] {
      new Object[] { 5, 3,2 }
    };
  }
  @DataProvider
  public Object[][] multiplication() {
    return new Object[][] {
      new Object[] { 1, 2,2 }
    };
  }
  @DataProvider
  public Object[][] division() {
    return new Object[][] {
      new Object[] { 10, 2,5 }
    };
  }
}
